package world;


import java.awt.image.BufferedImage;


public class Assets {
	
	private static final int width = 32, height = 32;
	
	public static BufferedImage player,cloud,grass, stone, tree,dirt,magma,stairs,fontanaRossa,rocciaFuoco;

	public static void init(){
		SpriteSheet sheetHell = new SpriteSheet(ImageLoader.loadImage("/res/hell.png"));
                SpriteSheet sheetDante = new SpriteSheet(ImageLoader.loadImage("/res/dante.png"));
                // giocatore
                player = sheetDante.crop(0, 0, 24, 32);
	        //tiles per paradiso
                cloud = sheetHell.crop(width * 4, 0, width, height);
		grass = sheetHell.crop(width * 4, 0, width, height);
		// inferno
                stone = sheetHell.crop(width * 3, 0, width, height);
		tree = sheetHell.crop(0, height, width, height);
                
                magma = sheetHell.crop(width * 7, height*9, width, height);
                dirt = sheetHell.crop(width * 6, height*2, width, height);
                stairs =sheetHell.crop(width * 2, height * 3, width, height);
                fontanaRossa=sheetHell.crop(0, 0, width, height);
                rocciaFuoco =sheetHell.crop(width * 3, height * 2, width, height);
	}
	
}
