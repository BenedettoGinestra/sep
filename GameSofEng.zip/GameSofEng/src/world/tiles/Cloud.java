package world.tiles;

import world.Assets;


public class Cloud extends Tile {

	public Cloud(int id) {
		super(Assets.cloud, id);
	}

}
