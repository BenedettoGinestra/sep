package stati;

import avvio.Game;
import entita.Player;
import java.awt.Graphics;
import world.World;


public class GameState extends State {
	
	private Player player;
	private World world;
	
	public GameState(Game game){
		super(game);
		player = new Player(game, 130, 300);
		world = new World("src/res/hell.txt");
	}
	
	@Override
	public void tick() {
		world.tick();
		player.tick();
	}

	@Override
	public void render(Graphics g) {
		world.render(g);
		player.render(g);
	}
        public World getWorld(){
            return world;
        }
}
