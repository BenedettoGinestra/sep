package entita;

import avvio.Game;
import design.PauseMenu;
import java.awt.Color;
import java.awt.Graphics;
import world.Assets;



public class Player extends Creature {

	
	public Player(Game game, float x, float y) {
		super(game,x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
	}

	public void tick() {
		getInput();
		move();
                // ora per non far andare fuori dalla mappa,ma da migliorare
                // con collision detection sul magma
//                if(x<=0)
//                    x=0;
//                if(x>=game.width-32)
//                    x=game.width-32;
//                if(y<=0)
//                    y=0;
//                if(y>=game.height-32)
//                    y=game.height-32;
                 
	}
	
	private void getInput(){
		xMove = 0;
		yMove = 0;
		
		if(game.getKeyManager().up)
			yMove = -speed;
		if(game.getKeyManager().down)
			yMove = speed;
		if(game.getKeyManager().left)
			xMove = -speed;
		if(game.getKeyManager().right)
			xMove = speed;
                 //se premo il tasto spazio, metto il gioco in pausa
                if (game.getKeyManager().pause){
                    PauseMenu pause = new PauseMenu();
                    pause.setLocation(300,110);
                    pause.setVisible(true);
                    game.pause();
                }             
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.player, (int) x, (int) y, width, height, null);  
        }

}
