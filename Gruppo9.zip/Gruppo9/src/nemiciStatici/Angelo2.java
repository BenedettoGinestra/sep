package nemiciStatici;

import avvio.Handler;
import java.awt.Graphics;
import world.Assets;
import world.tiles.Tile;


public class Angelo2 extends StaticEntity {

	public Angelo2(Handler handler, float x, float y) {
            //nemici prendo più grandi
		super(handler, x, y, Tile.TILEWIDTH*2, Tile.TILEHEIGHT * 2);
	}
        
	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
            	g.drawImage(Assets.angelo2, (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null);
	}
        @Override
	public void die(){
		
	}
}
