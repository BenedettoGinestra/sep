package world;

import avvio.Handler;
import entita.EntityManager;
import entita.Player;
import java.awt.Graphics;
import nemiciStatici.Angelo1;
import nemiciStatici.Angelo2;
import nemiciStatici.Demone;
import nemiciStatici.FinalBoss;
import world.tiles.Tile;


public class World {
    
        private Handler handler;
	private int width, height; // dimensioni mappa
	private int[][] tiles; // matrice per posizionare le tiles tramite i loro ID (int)
        private int spawnX;
        private int spawnY;
        
        //Entities
	private EntityManager entityManager;
        
	// path del file dove risiede il world
	public World(Handler handler,String path){
                this.handler=handler;
		
                
                entityManager = new EntityManager(handler, new Player(handler, 130, 300));
		// Temporary entity code!
		entityManager.addEntity(new Angelo1(handler, 600, 275));
		//entityManager.addEntity(new Angelo1(handler, 300, 450));
		//entityManager.addEntity(new Angelo1(handler, 500, 300));
                entityManager.addEntity(new Angelo2(handler, 350, 150));
		entityManager.addEntity(new Angelo2(handler, 350, 450));
		entityManager.addEntity(new Demone(handler, 1300, 300));
                entityManager.addEntity(new Demone(handler, 1700, 300));
                entityManager.addEntity(new FinalBoss(handler, 2000, 275));
                
                loadWorld(path);
                // posizione player,la seconda riga del file txt
                entityManager.getPlayer().setX(spawnX);
		entityManager.getPlayer().setY(spawnY);
	}
	
	public void tick(){
		entityManager.tick();
	}
	
	public void render(Graphics g){
		int xStart = (int) Math.max(0, handler.getGameCamera().getxOffset() / Tile.TILEWIDTH);
		int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffset() + handler.getWidth()) / Tile.TILEWIDTH + 1);
		int yStart = (int) Math.max(0, handler.getGameCamera().getyOffset() / Tile.TILEHEIGHT);
		int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffset() + handler.getHeight()) / Tile.TILEHEIGHT + 1);
		
		for(int y = yStart;y < yEnd;y++){
			for(int x = xStart;x < xEnd;x++){
				getTile(x, y).render(g, (int) (x * Tile.TILEWIDTH - handler.getGameCamera().getxOffset()),
						(int) (y * Tile.TILEHEIGHT - handler.getGameCamera().getyOffset()));
			}
		}
		//Entities
		entityManager.render(g);
	}
	// facciamo ritornare tile,se non lo trova ritorna rock,per non lasciare buchi nella canvas
	public Tile getTile(int x, int y){

                // tiles[x][y] prendo l'elemento(ID) e vedo che tile è
		Tile t = Tile.tiles[tiles[x][y]];
		if(t == null)
			return Tile.magmaTile; // default tile
		return t;
	}
	// prendo percorso e carico il file dentro la matrice delle posizioni
	private void loadWorld(String path){
                // carico contenuto file come stringhe
		String file = Utils.loadFileAsString(path);
                // \\s+-->spit della matrice di stringhe in caratteri individuali 
                // separati da uno spazio bianco o carattere di new line \n
                // e metto nel vettore tokens
		String[] tokens = file.split("\\s+");
                // leggo il primo numero del file.txt cioè il numero di colonne
                // che indica la larghezza della mappa
		width = Utils.parseInt(tokens[0]);
                // analogamente l'altezza
		height = Utils.parseInt(tokens[1]);
                // da dove costruire la mappa
                spawnX = Utils.parseInt(tokens[2]);
		spawnY = Utils.parseInt(tokens[3]);
		
		tiles = new int[width][height];
                
		for(int y = 0;y < height;y++){
			for(int x = 0;x < width;x++){
                                // ora tutto leggo tutto dal vettore tiles,+4 perche i primi quattro posti
                                // li abbiamo letti precedentemente
				tiles[x][y] = Utils.parseInt(tokens[(x + y * width) + 4]);
			}
		}
	}
        public int getWidth(){
		return width;
	}
	
	public int getHeight(){
		return height;
	}
	public EntityManager getEntityManager() {
		return entityManager;
	}
}
