package world;


import java.awt.image.BufferedImage;


public class Assets {
	
	private static final int width = 32, height = 32;
	
	public static BufferedImage player,nemico,demone,angelo1,angelo2,boss,cloud0,
                cloud1,cloud2,cloud3,cloud4,sky,grass,
                stone, tree,dirt,magma,stairs,fontanaRossa,rocciaFuoco,
                stone1,stone2;

	public static void init(){
            
		SpriteSheet sheetHell = new SpriteSheet(ImageLoader.loadImage("/res/hell.png"));
                SpriteSheet sheetHeaven = new SpriteSheet(ImageLoader.loadImage("/res/heaven.png"));
                SpriteSheet sheetSky = new SpriteSheet(ImageLoader.loadImage("/res/h.png"));
                SpriteSheet sheetAngelo1 = new SpriteSheet(ImageLoader.loadImage("/res/angelo.png"));
                SpriteSheet sheetAngelo2 = new SpriteSheet(ImageLoader.loadImage("/res/angelo2.png"));

                SpriteSheet sheetDante = new SpriteSheet(ImageLoader.loadImage("/res/dante.png"));
                
                // giocatore
                player = sheetDante.crop(0, 0, 24, 32);
                
                
	        //tiles per paradiso,i primi 4 sono gli angoli della nuvola
                cloud1 = sheetHeaven.crop(0, 0, width, height);
                cloud2 = sheetHeaven.crop(0 , height, width, height);
                cloud3 = sheetHeaven.crop(width , 0, width, height);//angolo in alto a sinistra
                cloud4 = sheetHeaven.crop(width , height, width, height);
                // nuvola centrale
                cloud0 = sheetSky.crop(0, height, width*2, height*2);
		grass = sheetHell.crop(width * 4, 0, width, height);
                sky = sheetSky.crop(0, 0, width/2, height/2);
                // purgatorio
                stone1 = sheetHell.crop(width , height*2, width, height);
                stone2 = sheetHell.crop(width * 7, height*2, width, height);
		// inferno
                stone = sheetHell.crop(width * 3, 0, width, height);
		tree = sheetHell.crop(0, height, width, height);
                
                magma = sheetHell.crop(width * 7, height*9, width, height);
                dirt = sheetHell.crop(width * 6, height*2, width, height);
                stairs =sheetHell.crop(width * 2, height * 3, width, height);
                fontanaRossa=sheetHell.crop(0, 0, width, height);
                rocciaFuoco =sheetHell.crop(width * 3, height * 2, width, height);
                
                
                // nemici
                demone =sheetHell.crop(width*1, height*5, width, height);
                nemico =sheetHell.crop(width*6, height*4, width, height);
                angelo1 =sheetAngelo1.crop(0, 0, width, height);
                angelo2 =sheetAngelo2.crop(0, 0, width, height);
                boss =sheetHell.crop(width*9, height*8, 32, 64);
	}
	
}
