package world.tiles;

import world.Assets;


public class StonePurgatory2 extends Tile {

	public StonePurgatory2(int id) {
		super(Assets.stone2, id);
	}

}
