package world.tiles;

import world.Assets;


public class RocciaFuocoTile extends Tile {

	public RocciaFuocoTile(int id) {
		super(Assets.rocciaFuoco, id);
	}

}
