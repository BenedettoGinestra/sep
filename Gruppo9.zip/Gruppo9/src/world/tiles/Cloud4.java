package world.tiles;

import world.Assets;


public class Cloud4 extends Tile {

	public Cloud4(int id) {
		super(Assets.cloud4, id);
	}

}
