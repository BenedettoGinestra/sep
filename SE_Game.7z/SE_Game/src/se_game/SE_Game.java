/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se_game;

import mob.*;
import com.sun.glass.events.KeyEvent;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

/**
 *
 * @author bened
 */
public class SE_Game {

    /**
     * @param args the command line arguments
     *
     */
    public static void main(String[] args) throws InterruptedException {
        
        JFrame frame = new JFrame();
        Mob mob = new Mob();
        mob.attachDownMoveSprites("./resources/img/dante2_100px.png");
        mob.attachLeftMoveSprites("./resources/img/danteSXcamminata2_100px.png");
        mob.attachUpMoveSprites("./resources/img/dante3_100px.png");
        mob.attachRightMoveSprites("./resources/img/dante4_100px.png");
        frame.add(mob);
        
        mob.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_A, 0), "a_pressed");
        mob.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_S, 0), "s_pressed");
        mob.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_D, 0), "d_pressed");
        mob.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_W, 0), "w_pressed");
        mob.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_P, 0), "p_pressed"); // tasto per la PAUSA

        Action actionD = new MoveRight(mob);
        Action actionA = new MoveLeft(mob);
        Action actionS = new MoveDown(mob);
        Action actionW = new MoveUp(mob);
        Action actionP = new PauseAction(frame); // PAUSA
        actionA.setEnabled(true);
        actionD.setEnabled(true);
        actionS.setEnabled(true);
        actionW.setEnabled(true);
        actionP.setEnabled(true);
        

        mob.getActionMap().put("a_pressed", actionA);
        mob.getActionMap().put("s_pressed", actionS);
        mob.getActionMap().put("d_pressed", actionD);
        mob.getActionMap().put("w_pressed", actionW);
        mob.getActionMap().put("p_pressed", actionP);
        

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }

}
