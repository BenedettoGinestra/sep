/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se_game;

import mob.*;
import com.sun.glass.events.KeyEvent;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.KeyAdapter;
import java.beans.PropertyChangeListener;
import javax.swing.AbstractAction;
import javax.swing.Action;
import javax.swing.ActionMap;
import javax.swing.InputMap;
import javax.swing.JFrame;
import javax.swing.KeyStroke;

/**
 *
 * @author bened
 */
public class SE_Game {

    /**
     * @param args the command line arguments
     *
     */
    public static void main(String[] args) throws InterruptedException {
        
        JFrame frame = new JFrame();
        Mob gb = new Mob();
        frame.add(gb);
        
        gb.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_A, 0), "a_pressed");
        gb.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_S, 0), "s_pressed");
        gb.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_D, 0), "d_pressed");
        gb.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_W, 0), "w_pressed");
        gb.getInputMap().put(KeyStroke.getKeyStroke(KeyEvent.VK_P, 0), "p_pressed"); // tasto per la PAUSA

        Action actionD = new MoveRight(gb);
        Action actionA = new MoveLeft(gb);
        Action actionS = new MoveDown(gb);
        Action actionW = new MoveUp(gb);
        Action actionP = new PauseAction(frame); // PAUSA
        actionA.setEnabled(true);
        actionD.setEnabled(true);
        actionS.setEnabled(true);
        actionW.setEnabled(true);
        actionP.setEnabled(true);
        

        gb.getActionMap().put("a_pressed", actionA);
        gb.getActionMap().put("s_pressed", actionS);
        gb.getActionMap().put("d_pressed", actionD);
        gb.getActionMap().put("w_pressed", actionW);
        gb.getActionMap().put("p_pressed", actionP);
        

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }

}
