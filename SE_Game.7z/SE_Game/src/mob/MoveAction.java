/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mob;

import javax.swing.AbstractAction;

/**
 *
 * @author bened
 */
public abstract class MoveAction extends AbstractAction {
    protected Mob mob;
    
    protected MoveAction(Mob mob) {
        this.mob = mob;
    }
}
