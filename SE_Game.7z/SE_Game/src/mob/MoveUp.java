/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mob;

import mob.Mob;
import java.awt.event.ActionEvent;
import javax.swing.AbstractAction;

/**
 *
 * @author bened
 */
public class MoveUp 
        extends AbstractAction {
    
       private Mob gb;
       
       public MoveUp(Mob gb)
       {
           this.gb = gb;
       }

        @Override
        public void actionPerformed(ActionEvent e) {
            gb.moveUp();
        }
       
   }