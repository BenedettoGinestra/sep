/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mob;

import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;

/**
 *
 * @author bened
 */
public class SpritesheetManagerTest extends JComponent{
   //private static BufferedImage bi = new BufferedImage(100,100,BufferedImage.TYPE_3BYTE_BGR);
         static ImageIcon ic = new ImageIcon("./resources/img/trump_run.png");
   static SpritesheetManagerTest smt = new SpritesheetManagerTest();
   static BufferedImage[] sprites = new BufferedImage[24];
   static BufferedImage bi;

   public static void main(String[] args) throws IOException
   {
       bi   = ImageIO.read(new File("./resources/img/trump_run.png"));
       JFrame frame = new JFrame();
       frame.add(smt);
       for(int i = 0 ; i < 4 ; i++)
           for(int j = 0 ; j < 6 ; j++)
           {
               sprites[i * 6 + j] = bi.getSubimage(j * 50, i * 50, 50, 50);
           }
       
       Canvas c = new Canvas();
       frame.add(c);
       System.out.println(c.getGraphics());
       frame.pack();
       c.setVisible(true);
       /*c.getGraphics().drawImage(.getImage()
               ,
               0, 0,
               smt);*/

       //frame.repaint();
       /*bi.getSubimage(0, 0, 100, 100).getGraphics().drawRect(0, 0, 100, 100);//drawImage(ic.getImage(), 0, 0, smt);
       smt.repaint();*/
       frame.setSize(new Dimension(200,200));
       frame.setPreferredSize(new Dimension(200,200));
       frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       frame.pack();
       smt.repaint();
       //smt.paint(smt.getGraphics());
       frame.setVisible(true);
   }
   
   public void paint(Graphics g) {
      g.drawImage(sprites[1], 100, 100, null);
   }

}
