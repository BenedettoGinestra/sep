package world.tiles;

import world.Assets;


public class Cloud2 extends Tile {

	public Cloud2(int id) {
		super(Assets.cloud2, id);
	}

}
