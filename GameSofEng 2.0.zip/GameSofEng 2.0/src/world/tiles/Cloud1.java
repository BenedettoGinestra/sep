package world.tiles;

import world.Assets;


public class Cloud1 extends Tile {

	public Cloud1(int id) {
		super(Assets.cloud1, id);
	}

}
