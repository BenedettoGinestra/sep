package world.tiles;

import world.Assets;


public class DemoneTile extends Tile {

	public DemoneTile(int id) {
		super(Assets.demone, id);
	}

}
