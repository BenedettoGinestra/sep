package world.tiles;

import world.Assets;


public class GrassTile extends Tile {

	public GrassTile(int id) {
		super(Assets.grass, id);
	}

}
