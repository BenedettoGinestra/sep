package world.tiles;

import world.Assets;


public class FontanaRossaTile extends Tile {

	public FontanaRossaTile(int id) {
		super(Assets.fontanaRossa, id);
	}

}
