package world.tiles;

import world.Assets;


public class StairsTile extends Tile {

	public StairsTile(int id) {
		super(Assets.stairs, id);
	}

}
