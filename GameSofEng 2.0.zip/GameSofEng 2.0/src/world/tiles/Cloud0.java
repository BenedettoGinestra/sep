package world.tiles;

import world.Assets;


public class Cloud0 extends Tile {

	public Cloud0(int id) {
		super(Assets.cloud0, id);
	}

}
