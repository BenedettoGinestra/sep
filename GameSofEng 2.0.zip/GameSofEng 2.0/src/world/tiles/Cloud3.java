package world.tiles;

import world.Assets;


public class Cloud3 extends Tile {

	public Cloud3(int id) {
		super(Assets.cloud3, id);
	}

}
